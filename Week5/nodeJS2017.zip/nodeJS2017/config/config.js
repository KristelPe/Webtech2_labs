const config = {
    port: 3000 ,
    mongoose.connect('mongodb://localhost/nodejs-introduction')
};

module.exports = config;
/**
 * Created by Crystal on 17/03/17.
 */
const mongoose = require('mongoose');
const Schema = mongoose.schema;

const AlbumSchema = new Schema({
    titel: {type: String, required: true},
    artist: {type: String, required: true},
    imageUrl: {type: String},
});

const AlbumModel = mongoose.model('Album', AlbumSchema);

module.exports = AlbumModel
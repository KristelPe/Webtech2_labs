const express = require("express");
const chalk = require("chalk");
const mongoose = require("mongoose");
const albumRouter = require('./routes/album');
const Album = require('./models/album.js');
const config = require('./config/config');      //.js moet niet achter filename mag wel    -    ./ => vertrek van huidige map
const bodyParser = require('./routes/album');

//console.log(chalk.blue("Hello IMD!"));

mongoose.connect(config.database);

const App = express();
App.use(bodyParser.json());
albumRouter(App);

App.get('/', (req, res) => {
    res.send('Hello World!');
});

App.listen(config.port,() => {
    console.log('Example running on port' + config.port)
    //console.log('Example app listening on port ${config.port}!')
});


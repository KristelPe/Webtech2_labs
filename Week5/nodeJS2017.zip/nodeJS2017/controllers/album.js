const create = require('../models/album.js');

const create = (req, res, next) => {
     const Album = new Album({
         title: 'AM',
         artist: 'Artic Monkeys',
         imageUrl: 'http://www.cbsouthtribune.com/wp-content/uploads/2013/10/am.jpg',
     });

     album.save((err, result) = > {
         if (err){
            res.status(500);
            return res.send(err);
         }
        res.json(result);
     });
 }

const list = (req, res, next) => {
    Album.find().exec((err, results) => {
        if (err){
            return res.status(500).send(err);
        }
        return res.json(results);
    });
}

module.exports = {
    create: create,
    list: list
}

